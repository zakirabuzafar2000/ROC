Commands For First Time:

pkg update -y && pkg upgrade -y

pkg install python -y

pkg install git -y

git clone https://github.com/RootOfCyber/roc-x

Commands For All Time:

cd roc-x

python main.py .

. . . . . .

We Are On :

Youtube:

https://www.youtube.com/c/RootOfCyber

Facebook:

https://www.facebook.com/RootOfCyber

What's app:

https://chat.whatsapp.com/JPTOWlsJhhgEVtzht4tAlr

Telegram:

https://t.me/joinchat/JruEd1OzoFJDq9fBlh-Jkg

Contact Us:

rootofcyber@gmail.com